(function() {
	var $body = document.body,
		$menu_trigger = $body.getElementsByClassName('menu-trigger')[0];

	if (typeof $menu_trigger !== 'undefined') {
		$menu_trigger.addEventListener('click', function() {
			$body.classList.toggle('menu-active'); // Alternar la clase 'menu-active'
		});
	}
}).call(this);

document.getElementById('equipos').addEventListener('click', function() {
    document.getElementById('recuadro-equipos').style.display = 'block';
    document.getElementById('fondo-borroso').style.display = 'block';
});

document.getElementById('suscribete').addEventListener('click', function() {
    document.getElementById('recuadro-suscribete').style.display = 'block';
    document.getElementById('fondo-borroso').style.display = 'block';
});
document.getElementById('fondo-borroso').addEventListener('click', function() {
    document.getElementById('recuadro-equipos').style.display = 'none';
    document.getElementById('recuadro-suscribete').style.display = 'none';
    document.getElementById('fondo-borroso').style.display = 'none';
});
